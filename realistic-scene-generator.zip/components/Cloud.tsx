import React from 'react';

interface FruitStallProps {
  className?: string;
}

export const FruitStall: React.FC<FruitStallProps> = ({ className }) => {
  return (
    <div className={className}>
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
        {/* Stall Structure */}
        <rect x="10" y="100" width="180" height="80" fill="#A0522D" stroke="#5C2E0E" strokeWidth="2" />
        <rect x="20" y="50" width="10" height="130" fill="#8B4513" />
        <rect x="170" y="50" width="10" height="130" fill="#8B4513" />
        {/* Awning */}
        <path d="M 10 50 L 200 50 L 180 20 L 30 20 Z" fill="white" stroke="red" strokeWidth="2" />
        <path d="M 30 20 L 40 50 M 60 20 L 70 50 M 90 20 L 100 50 M 120 20 L 130 50 M 150 20 L 160 50" stroke="red" strokeWidth="2" />

        {/* Fruits */}
        <g>
          {/* Apples */}
          <circle cx="50" cy="130" r="10" fill="red" />
          <circle cx="70" cy="130" r="10" fill="red" />
          <circle cx="60" cy="115" r="10" fill="#DC143C" />
          {/* Oranges */}
          <circle cx="120" cy="140" r="12" fill="orange" />
          <circle cx="145" cy="140" r="12" fill="orange" />
          <circle cx="132" cy="120" r="12" fill="#FF8C00" />
           {/* Bananas */}
          <path d="M 80 160 Q 90 140, 110 160" stroke="yellow" strokeWidth="8" fill="none" />
          <path d="M 85 165 Q 95 145, 115 165" stroke="#FFD700" strokeWidth="8" fill="none" />
        </g>
      </svg>
    </div>
  );
};