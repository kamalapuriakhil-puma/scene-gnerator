import React from 'react';

interface VegetableStallProps {
  className?: string;
}

export const VegetableStall: React.FC<VegetableStallProps> = ({ className }) => {
  return (
    <div className={className} aria-hidden="true">
      <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
         {/* Stall Structure */}
        <rect x="10" y="100" width="180" height="80" fill="#A0522D" stroke="#5C2E0E" strokeWidth="2" />
        <rect x="20" y="50" width="10" height="130" fill="#8B4513" />
        <rect x="170" y="50" width="10" height="130" fill="#8B4513" />
        {/* Awning */}
        <path d="M 10 50 L 200 50 L 180 20 L 30 20 Z" fill="white" stroke="green" strokeWidth="2" />
        <path d="M 30 20 L 40 50 M 60 20 L 70 50 M 90 20 L 100 50 M 120 20 L 130 50 M 150 20 L 160 50" stroke="green" strokeWidth="2" />

        {/* Vegetables */}
        <g>
          {/* Tomatoes */}
          <circle cx="50" cy="150" r="10" fill="#ff6347" />
          <circle cx="70" cy="150" r="10" fill="#ff6347" />
          <circle cx="60" cy="135" r="10" fill="#ff4500" />
          
          {/* Cabbages */}
          <circle cx="120" cy="140" r="15" fill="#90ee90" />
          <circle cx="150" cy="140" r="15" fill="#3cb371" />

          {/* Carrots */}
          <polygon points="80,110 90,130 75,125" fill="orange" />
          <polygon points="90,110 100,130 85,125" fill="orange" />
        </g>
      </svg>
    </div>
  );
};