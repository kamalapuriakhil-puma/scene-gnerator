import React from 'react';

interface BoyProps {
  className?: string;
}

export const Boy: React.FC<BoyProps> = ({ className }) => {
  return (
    <svg 
      viewBox="0 0 200 300" 
      xmlns="http://www.w3.org/2000/svg" 
      className={className}
    >
      <g>
        {/* Head */}
        <circle cx="100" cy="50" r="30" fill="#f2d5b1" />
        <path d="M 80 20 Q 100 10, 120 20 L 110 0 L 90 0 Z" fill="#333" /> {/* Hair */}
        
        {/* Body */}
        <path d="M 80 80 L 120 80 L 130 150 L 70 150 Z" fill="#008000" /> {/* Green T-shirt */}
        
        {/* Apple */}
        <circle cx="135" cy="110" r="10" fill="red" />
        <path d="M 135 100 Q 137 95, 140 100" stroke="brown" strokeWidth="2" fill="none" />
        
        {/* Arms */}
        <path d="M 70 90 Q 50 110, 70 130" fill="none" stroke="#f2d5b1" strokeWidth="15" strokeLinecap="round" />
        <path d="M 130 90 Q 150 110, 130 130" fill="none" stroke="#f2d5b1" strokeWidth="15" strokeLinecap="round" />
        
        {/* Legs - Blue Jeans with running animation */}
        <g>
            {/* Left Leg */}
            <path d="M 85 150 L 80 250 L 70 250 L 75 150 Z" fill="#0000FF">
                <animateTransform
                    attributeName="transform"
                    type="rotate"
                    values="0 85 150; 20 85 150; 0 85 150"
                    dur="0.5s"
                    repeatCount="indefinite"
                />
            </path>
             {/* Right Leg */}
            <path d="M 115 150 L 120 250 L 130 250 L 125 150 Z" fill="#0000FF">
                 <animateTransform
                    attributeName="transform"
                    type="rotate"
                    values="0 115 150; -20 115 150; 0 115 150"
                    dur="0.5s"
                    repeatCount="indefinite"
                />
            </path>
        </g>
        
        {/* Shoes */}
        <ellipse cx="75" cy="250" rx="15" ry="5" fill="#5C2E0E" />
        <ellipse cx="125" cy="250" rx="15" ry="5" fill="#5C2E0E" />
      </g>
    </svg>
  );
};