import React from 'react';

interface StreetBackgroundProps {
  className?: string;
}

export const StreetBackground: React.FC<StreetBackgroundProps> = ({ className }) => {
  return (
    <div className={className} aria-hidden="true">
      <svg
        viewBox="0 0 1440 900"
        xmlns="http://www.w3.org/2000/svg"
        preserveAspectRatio="xMidYMid slice"
        className="w-full h-full"
      >
        {/* Sky */}
        <rect width="1440" height="400" fill="#a7d8de" />

        {/* Ground */}
        <rect y="400" width="1440" height="500" fill="#d2b48c" />
        
        {/* Road */}
        <polygon points="520,400 920,400 1440,900 0,900" fill="#888" />

        {/* Far Buildings */}
        <rect x="600" y="300" width="240" height="100" fill="#f5deb3" />
        <rect x="620" y="320" width="30" height="60" fill="#a0522d" />
        <rect x="670" y="320" width="30" height="60" fill="#a0522d" />
        <rect x="720" y="320" width="30" height="60" fill="#a0522d" />
        <rect x="770" y="320" width="30" height="60" fill="#a0522d" />

        {/* Left Buildings */}
        <polygon points="0,900 0,200 520,400 520,900" fill="#e9967a" />
        <rect x="50" y="250" width="80" height="80" fill="#a0522d" />
        <rect x="200" y="280" width="80" height="80" fill="#a0522d" />
        <rect x="350" y="320" width="80" height="80" fill="#a0522d" />
        <rect x="100" y="550" width="120" height="120" fill="#a0522d" />

        {/* Right Buildings */}
        <polygon points="1440,900 1440,200 920,400 920,900" fill="#f4a460" />
        <rect x="1310" y="250" width="80" height="80" fill="#8b4513" />
        <rect x="1160" y="280" width="80" height="80" fill="#8b4513" />
        <rect x="1010" y="320" width="80" height="80" fill="#8b4513" />
        <rect x="1220" y="550" width="120" height="120" fill="#8b4513" />

      </svg>
    </div>
  );
};