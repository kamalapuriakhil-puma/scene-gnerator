import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";

const App: React.FC = () => {
  const defaultPrompt = "A realistic, cinematic, high-detail photograph of a bustling street in Mumbai. The street is crowded with vibrant fruit and vegetable shops under colorful awnings. An 18-year-old Indian boy, wearing modern blue jeans and a green t-shirt, is captured mid-stride, running towards the camera with a look of urgency. He is clutching a shiny red apple. The scene is filled with the chaotic energy of a market, with motion blur indicating his speed. The lighting is a bright, late afternoon sun, casting long, dramatic shadows.";

  const [prompt, setPrompt] = useState<string>(defaultPrompt);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const generateImage = async () => {
    if (!prompt) {
      setError("Please enter a prompt.");
      return;
    }
    setLoading(true);
    setError(null);
    setImageUrl(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: '16:9',
        },
      });

      const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
      const url = `data:image/jpeg;base64,${base64ImageBytes}`;
      setImageUrl(url);
    } catch (e) {
      console.error(e);
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(`Failed to generate image. ${errorMessage}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="bg-gray-100 min-h-screen flex flex-col items-center p-4 sm:p-6 md:p-8">
      <div className="w-full max-w-4xl bg-white rounded-xl shadow-lg p-6 md:p-8">
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-800 text-center mb-2">
          Realistic Scene Generator
        </h1>
        <p className="text-center text-gray-500 mb-6">
          Describe the scene you want to create and let AI bring it to life.
        </p>

        <div className="flex flex-col gap-4">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-200 resize-none"
            rows={5}
            placeholder="e.g., A futuristic city skyline at sunset..."
            aria-label="Scene description prompt"
          />
          <button
            onClick={generateImage}
            disabled={loading}
            className="w-full bg-blue-600 text-white font-semibold py-3 px-6 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors duration-200 flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Generating...
              </>
            ) : (
              'Generate Image'
            )}
          </button>
        </div>

        <div className="mt-8 w-full min-h-[300px] bg-gray-200 rounded-lg flex items-center justify-center border border-dashed border-gray-400">
          {loading && (
            <div className="text-center text-gray-600">
              <p className="font-semibold">Generating your masterpiece...</p>
              <p className="text-sm">This may take a moment.</p>
            </div>
          )}
          {error && (
            <div className="text-center text-red-600 p-4">
              <p className="font-bold">An error occurred</p>
              <p>{error}</p>
            </div>
          )}
          {!loading && !error && imageUrl && (
            <img 
              src={imageUrl} 
              alt="Generated scene based on prompt" 
              className="rounded-lg object-contain w-full h-full"
            />
          )}
           {!loading && !error && !imageUrl && (
            <p className="text-gray-500">Your generated image will appear here.</p>
          )}
        </div>
      </div>
    </main>
  );
};

export default App;
